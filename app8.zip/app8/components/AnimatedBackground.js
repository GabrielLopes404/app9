import React, { useEffect } from 'react';
import { StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  useSharedValue,
  useAnimatedProps,
  withRepeat,
  withTiming,
  interpolateColor,
  Easing,
} from 'react-native-reanimated';
import { Colors } from '../constants/theme';

const AnimatedLinearGradient = Animated.createAnimatedComponent(LinearGradient);

export default function AnimatedBackground({ 
  gradientColors = Colors.gradientTwilight,
  duration = 8000,
  style,
  children,
}) {
  const progress = useSharedValue(0);

  useEffect(() => {
    progress.value = withRepeat(
      withTiming(1, {
        duration,
        easing: Easing.inOut(Easing.ease),
      }),
      -1,
      true
    );
  }, [duration]);

  const animatedProps = useAnimatedProps(() => {
    const colors = gradientColors.length >= 2 ? [
      interpolateColor(
        progress.value,
        [0, 0.5, 1],
        [gradientColors[0], gradientColors[1] || gradientColors[0], gradientColors[0]]
      ),
      interpolateColor(
        progress.value,
        [0, 0.5, 1],
        [gradientColors[1] || gradientColors[0], gradientColors[0], gradientColors[1] || gradientColors[0]]
      ),
    ] : gradientColors;

    return {
      colors,
    };
  });

  return (
    <AnimatedLinearGradient
      animatedProps={animatedProps}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={[StyleSheet.absoluteFill, style]}
    >
      {children}
    </AnimatedLinearGradient>
  );
}
