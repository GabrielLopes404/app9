import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';
import Button from '../components/Button';

function TimeSlot({ time, selected, available, onPress }) {
  return (
    <TouchableOpacity
      style={[
        styles.timeSlot,
        selected && styles.timeSlotSelected,
        !available && styles.timeSlotDisabled,
      ]}
      onPress={onPress}
      disabled={!available}
      activeOpacity={0.8}
    >
      <Text style={[
        styles.timeSlotText,
        selected && styles.timeSlotTextSelected,
        !available && styles.timeSlotTextDisabled,
      ]}>
        {time}
      </Text>
    </TouchableOpacity>
  );
}

export default function BookingScreen() {
  const router = useRouter();
  const [selectedDate, setSelectedDate] = useState(15);
  const [selectedTime, setSelectedTime] = useState(null);

  const dates = [
    { day: 13, weekday: 'Seg' },
    { day: 14, weekday: 'Ter' },
    { day: 15, weekday: 'Qua' },
    { day: 16, weekday: 'Qui' },
    { day: 17, weekday: 'Sex' },
    { day: 18, weekday: 'Sáb' },
    { day: 19, weekday: 'Dom' },
  ];

  const timeSlots = [
    { time: '09:00', available: true },
    { time: '10:00', available: true },
    { time: '11:00', available: false },
    { time: '12:00', available: false },
    { time: '14:00', available: true },
    { time: '15:00', available: true },
    { time: '16:00', available: true },
    { time: '17:00', available: false },
    { time: '18:00', available: true },
  ];

  const handleConfirm = () => {
    router.back();
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Agendar Serviço</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Selecione a data</Text>
          
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.datesContainer}
          >
            {dates.map((date) => (
              <TouchableOpacity
                key={date.day}
                style={[
                  styles.dateCard,
                  selectedDate === date.day && styles.dateCardSelected,
                ]}
                onPress={() => setSelectedDate(date.day)}
                activeOpacity={0.8}
              >
                <Text style={[
                  styles.weekday,
                  selectedDate === date.day && styles.weekdaySelected,
                ]}>
                  {date.weekday}
                </Text>
                <Text style={[
                  styles.day,
                  selectedDate === date.day && styles.daySelected,
                ]}>
                  {date.day}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Selecione o horário</Text>
          
          <View style={styles.timeSlotsGrid}>
            {timeSlots.map((slot, index) => (
              <TimeSlot
                key={index}
                time={slot.time}
                selected={selectedTime === slot.time}
                available={slot.available}
                onPress={() => setSelectedTime(slot.time)}
              />
            ))}
          </View>
        </View>

        {selectedTime && (
          <View style={styles.selectedInfo}>
            <Ionicons name="calendar" size={24} color={Colors.primary} />
            <View style={styles.selectedText}>
              <Text style={styles.selectedLabel}>Agendamento selecionado</Text>
              <Text style={styles.selectedValue}>
                {selectedDate} de Novembro às {selectedTime}
              </Text>
            </View>
          </View>
        )}
      </ScrollView>

      <View style={styles.footer}>
        <Button
          title="Confirmar agendamento"
          onPress={handleConfirm}
          disabled={!selectedTime}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.lg,
    backgroundColor: Colors.backgroundLight,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  headerTitle: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: Spacing.lg,
    paddingBottom: Spacing.xxxl,
  },
  section: {
    marginBottom: Spacing.xxxl,
  },
  sectionTitle: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginBottom: Spacing.lg,
  },
  datesContainer: {
    gap: Spacing.md,
  },
  dateCard: {
    width: 70,
    paddingVertical: Spacing.lg,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.backgroundLight,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: Colors.border,
  },
  dateCardSelected: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  weekday: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    marginBottom: Spacing.xs,
  },
  weekdaySelected: {
    color: Colors.textLight,
  },
  day: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
  },
  daySelected: {
    color: Colors.textLight,
  },
  timeSlotsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
  },
  timeSlot: {
    width: '30%',
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.backgroundLight,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: Colors.border,
  },
  timeSlotSelected: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  timeSlotDisabled: {
    backgroundColor: Colors.backgroundGray,
    borderColor: Colors.backgroundGray,
  },
  timeSlotText: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
  },
  timeSlotTextSelected: {
    color: Colors.textLight,
  },
  timeSlotTextDisabled: {
    color: Colors.textSecondary,
  },
  selectedInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.primary + '15',
    padding: Spacing.lg,
    borderRadius: BorderRadius.lg,
    gap: Spacing.md,
  },
  selectedText: {
    flex: 1,
  },
  selectedLabel: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    marginBottom: Spacing.xs,
  },
  selectedValue: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
  },
  footer: {
    padding: Spacing.lg,
    backgroundColor: Colors.backgroundLight,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
});
