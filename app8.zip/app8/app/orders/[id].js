import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeInDown, FadeIn, useAnimatedStyle, useSharedValue, withRepeat, withTiming, Easing } from 'react-native-reanimated';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../../constants/theme';

const trackingSteps = [
  { id: 1, title: 'Pedido confirmado', time: '14:30', completed: true, icon: 'checkmark-circle' },
  { id: 2, title: 'Preparando pedido', time: '14:45', completed: true, icon: 'restaurant' },
  { id: 3, title: 'Saiu para entrega', time: '15:20', completed: true, icon: 'bicycle', active: true },
  { id: 4, title: 'Entregue', time: '', completed: false, icon: 'home' },
];

function PulsingDot() {
  const scale = useSharedValue(1);
  const opacity = useSharedValue(1);

  useEffect(() => {
    scale.value = withRepeat(
      withTiming(1.3, { duration: 1500, easing: Easing.inOut(Easing.ease) }),
      -1,
      true
    );
    opacity.value = withRepeat(
      withTiming(0.3, { duration: 1500, easing: Easing.inOut(Easing.ease) }),
      -1,
      true
    );
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: opacity.value,
  }));

  return (
    <Animated.View style={[styles.pulseRing, animatedStyle]} />
  );
}

export default function OrderDetailScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const order = {
    id,
    orderNumber: '#PG2024-0847',
    status: 'Saiu para entrega',
    statusColor: Colors.warning,
    date: '10 de Nov, 2024',
    time: '14:30',
    estimatedDelivery: '16:00 - 16:30',
    store: {
      name: 'Pet Shop Central',
      image: 'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=200',
      phone: '(11) 98765-4321',
    },
    deliveryAddress: 'Rua das Flores, 123 - Centro\nSão Paulo, SP - 01234-567',
    items: [
      {
        id: '1',
        name: 'Ração Premium Golden 15kg',
        quantity: 1,
        price: 189.90,
        image: 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=200',
      },
      {
        id: '2',
        name: 'Brinquedo Kong Classic',
        quantity: 2,
        price: 49.90,
        image: 'https://images.unsplash.com/photo-1535294435445-d7249524ef2e?w=200',
      },
    ],
    payment: 'Cartão de Crédito •••• 1234',
    subtotal: 289.70,
    deliveryFee: 10.00,
    total: 299.70,
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <LinearGradient
          colors={[Colors.primary, Colors.accent]}
          style={styles.loadingGradient}
        >
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={Colors.textLight} />
            <Text style={styles.loadingText}>Carregando pedido...</Text>
          </View>
        </LinearGradient>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <LinearGradient
        colors={[Colors.primary, Colors.accent]}
        style={styles.headerGradient}
      >
        <View style={styles.header}>
          <TouchableOpacity 
            onPress={() => router.back()}
            style={styles.headerButton}
          >
            <Ionicons name="arrow-back" size={24} color={Colors.textLight} />
          </TouchableOpacity>
          
          <View style={styles.headerCenter}>
            <Text style={styles.headerTitle}>Pedido {order.orderNumber}</Text>
            <View style={styles.statusBadge}>
              <View style={[styles.statusDot, { backgroundColor: order.statusColor }]} />
              <Text style={styles.statusBadgeText}>{order.status}</Text>
            </View>
          </View>
          
          <TouchableOpacity style={styles.headerButton}>
            <Ionicons name="share-outline" size={24} color={Colors.textLight} />
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Delivery Estimate Card */}
        <Animated.View entering={FadeInDown.delay(100).springify()}>
          <LinearGradient
            colors={['#FFFFFF', '#F9FAFB']}
            style={styles.estimateCard}
          >
            <View style={styles.estimateIconContainer}>
              <LinearGradient
                colors={[Colors.warning + '30', Colors.warning + '10']}
                style={styles.estimateIconGradient}
              >
                <Ionicons name="time" size={28} color={Colors.warning} />
              </LinearGradient>
            </View>
            <View style={styles.estimateInfo}>
              <Text style={styles.estimateLabel}>Previsão de entrega</Text>
              <Text style={styles.estimateTime}>{order.estimatedDelivery}</Text>
              <Text style={styles.estimateDate}>{order.date}</Text>
            </View>
          </LinearGradient>
        </Animated.View>

        {/* Tracking Timeline */}
        <Animated.View entering={FadeInDown.delay(200).springify()}>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Acompanhamento do pedido</Text>
            
            <LinearGradient
              colors={['#FFFFFF', '#F9FAFB']}
              style={styles.trackingCard}
            >
              {trackingSteps.map((step, index) => (
                <View key={step.id} style={styles.trackingStep}>
                  <View style={styles.trackingIndicator}>
                    <View style={styles.trackingDotContainer}>
                      {step.active && <PulsingDot />}
                      <LinearGradient
                        colors={step.completed 
                          ? [Colors.primary, Colors.accent]
                          : [Colors.border, Colors.border]
                        }
                        style={[styles.trackingDot, step.active && styles.trackingDotActive]}
                      >
                        <Ionicons 
                          name={step.icon} 
                          size={18} 
                          color={step.completed ? Colors.textLight : Colors.textSecondary} 
                        />
                      </LinearGradient>
                    </View>
                    {index < trackingSteps.length - 1 && (
                      <LinearGradient
                        colors={step.completed 
                          ? [Colors.primary, Colors.accent]
                          : [Colors.border, Colors.border]
                        }
                        style={styles.trackingLine}
                      />
                    )}
                  </View>
                  
                  <View style={styles.trackingContent}>
                    <Text style={[
                      styles.trackingTitle,
                      !step.completed && styles.trackingTitleInactive,
                      step.active && styles.trackingTitleActive
                    ]}>
                      {step.title}
                    </Text>
                    {step.time && (
                      <View style={styles.trackingTimeContainer}>
                        <Ionicons name="time-outline" size={14} color={Colors.textSecondary} />
                        <Text style={styles.trackingTime}>{step.time}</Text>
                      </View>
                    )}
                  </View>
                </View>
              ))}
            </LinearGradient>
          </View>
        </Animated.View>

        {/* Store Info */}
        <Animated.View entering={FadeInDown.delay(300).springify()}>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Informações da loja</Text>
            
            <LinearGradient
              colors={['#FFFFFF', '#F9FAFB']}
              style={styles.storeCard}
            >
              <Image
                source={{ uri: order.store.image }}
                style={styles.storeImage}
                resizeMode="cover"
              />
              <View style={styles.storeInfo}>
                <Text style={styles.storeName}>{order.store.name}</Text>
                <TouchableOpacity style={styles.phoneButton} activeOpacity={0.8}>
                  <LinearGradient
                    colors={[Colors.primary + '15', Colors.accent + '15']}
                    style={styles.phoneButtonGradient}
                  >
                    <Ionicons name="call" size={16} color={Colors.primary} />
                    <Text style={styles.phoneText}>{order.store.phone}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </LinearGradient>
          </View>
        </Animated.View>

        {/* Delivery Address */}
        <Animated.View entering={FadeInDown.delay(350).springify()}>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Endereço de entrega</Text>
            
            <LinearGradient
              colors={['#FFFFFF', '#F9FAFB']}
              style={styles.addressCard}
            >
              <View style={styles.addressIconContainer}>
                <LinearGradient
                  colors={[Colors.primary + '20', Colors.primary + '10']}
                  style={styles.addressIconGradient}
                >
                  <Ionicons name="location" size={24} color={Colors.primary} />
                </LinearGradient>
              </View>
              <Text style={styles.addressText}>{order.deliveryAddress}</Text>
            </LinearGradient>
          </View>
        </Animated.View>

        {/* Order Items */}
        <Animated.View entering={FadeInDown.delay(400).springify()}>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Itens do pedido</Text>
            
            {order.items.map((item, index) => (
              <Animated.View 
                key={item.id} 
                entering={FadeInDown.delay(450 + (index * 50)).springify()}
              >
                <LinearGradient
                  colors={['#FFFFFF', '#F9FAFB']}
                  style={styles.itemCard}
                >
                  <Image
                    source={{ uri: item.image }}
                    style={styles.itemImage}
                    resizeMode="cover"
                  />
                  <View style={styles.itemInfo}>
                    <Text style={styles.itemName}>{item.name}</Text>
                    <View style={styles.itemQuantityContainer}>
                      <View style={styles.quantityBadge}>
                        <Text style={styles.itemQuantity}>{item.quantity}x</Text>
                      </View>
                      <Text style={styles.itemUnitPrice}>
                        R$ {item.price.toFixed(2)} cada
                      </Text>
                    </View>
                  </View>
                  <Text style={styles.itemPrice}>
                    R$ {(item.price * item.quantity).toFixed(2)}
                  </Text>
                </LinearGradient>
              </Animated.View>
            ))}
          </View>
        </Animated.View>

        {/* Payment Summary */}
        <Animated.View entering={FadeInDown.delay(550).springify()}>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Resumo do pagamento</Text>
            
            <LinearGradient
              colors={['#FFFFFF', '#F9FAFB']}
              style={styles.summaryCard}
            >
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Subtotal</Text>
                <Text style={styles.summaryValue}>R$ {order.subtotal.toFixed(2)}</Text>
              </View>
              
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Taxa de entrega</Text>
                <Text style={styles.summaryValue}>R$ {order.deliveryFee.toFixed(2)}</Text>
              </View>
              
              <View style={styles.summaryDivider} />
              
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabelTotal}>Total pago</Text>
                <LinearGradient
                  colors={[Colors.primary, Colors.accent]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.totalBadge}
                >
                  <Text style={styles.summaryValueTotal}>R$ {order.total.toFixed(2)}</Text>
                </LinearGradient>
              </View>
              
              <View style={styles.paymentMethodContainer}>
                <View style={styles.paymentIconContainer}>
                  <Ionicons name="card" size={20} color={Colors.primary} />
                </View>
                <Text style={styles.paymentText}>{order.payment}</Text>
              </View>
            </LinearGradient>
          </View>
        </Animated.View>

        {/* Action Buttons */}
        <Animated.View entering={FadeInDown.delay(600).springify()}>
          <View style={styles.actionsSection}>
            <TouchableOpacity style={styles.actionButtonPrimary} activeOpacity={0.8}>
              <LinearGradient
                colors={[Colors.primary, Colors.accent]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.actionButtonGradient}
              >
                <Ionicons name="navigate" size={20} color={Colors.textLight} />
                <Text style={styles.actionButtonTextPrimary}>Rastrear no mapa</Text>
              </LinearGradient>
            </TouchableOpacity>

            <View style={styles.secondaryActionsRow}>
              <TouchableOpacity style={styles.actionButtonSecondary} activeOpacity={0.8}>
                <LinearGradient
                  colors={['#FFFFFF', '#F9FAFB']}
                  style={styles.actionButtonSecondaryGradient}
                >
                  <Ionicons name="star" size={20} color={Colors.warning} />
                  <Text style={styles.actionButtonTextSecondary}>Avaliar pedido</Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity style={styles.actionButtonSecondary} activeOpacity={0.8}>
                <LinearGradient
                  colors={['#FFFFFF', '#F9FAFB']}
                  style={styles.actionButtonSecondaryGradient}
                >
                  <Ionicons name="repeat" size={20} color={Colors.primary} />
                  <Text style={styles.actionButtonTextSecondary}>Repetir pedido</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </Animated.View>

        {/* Help Button */}
        <Animated.View entering={FadeInDown.delay(650).springify()}>
          <TouchableOpacity style={styles.helpButton} activeOpacity={0.8}>
            <LinearGradient
              colors={[Colors.primary + '10', Colors.accent + '10']}
              style={styles.helpButtonGradient}
            >
              <Ionicons name="help-circle" size={22} color={Colors.primary} />
              <Text style={styles.helpText}>Precisa de ajuda com este pedido?</Text>
              <Ionicons name="chevron-forward" size={20} color={Colors.primary} />
            </LinearGradient>
          </TouchableOpacity>
        </Animated.View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  loadingGradient: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.lg,
  },
  loadingText: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.semibold,
    color: Colors.textLight,
  },
  headerGradient: {
    paddingBottom: Spacing.xl,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.md,
    gap: Spacing.md,
  },
  headerButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  headerCenter: {
    flex: 1,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
    marginBottom: Spacing.xs,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusBadgeText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.textLight,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: Spacing.lg,
  },
  estimateCard: {
    flexDirection: 'row',
    borderRadius: BorderRadius.xl,
    padding: Spacing.lg,
    marginBottom: Spacing.lg,
    alignItems: 'center',
    gap: Spacing.md,
    ...Shadows.medium,
  },
  estimateIconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    overflow: 'hidden',
  },
  estimateIconGradient: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  estimateInfo: {
    flex: 1,
  },
  estimateLabel: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    marginBottom: 2,
  },
  estimateTime: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  estimateDate: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
  },
  trackingCard: {
    borderRadius: BorderRadius.xl,
    padding: Spacing.lg,
    ...Shadows.medium,
  },
  trackingStep: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  trackingIndicator: {
    alignItems: 'center',
  },
  trackingDotContainer: {
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },
  trackingDot: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadows.small,
  },
  trackingDotActive: {
    ...Shadows.colored,
  },
  pulseRing: {
    position: 'absolute',
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: Colors.primary,
    opacity: 0.3,
  },
  trackingLine: {
    width: 3,
    flex: 1,
    marginVertical: 4,
    borderRadius: 2,
  },
  trackingContent: {
    flex: 1,
    paddingVertical: Spacing.xs,
    paddingBottom: Spacing.lg,
  },
  trackingTitle: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginBottom: Spacing.xs,
  },
  trackingTitleInactive: {
    color: Colors.textSecondary,
    fontWeight: FontWeights.medium,
  },
  trackingTitleActive: {
    color: Colors.primary,
    fontWeight: FontWeights.bold,
  },
  trackingTimeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  trackingTime: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  storeCard: {
    flexDirection: 'row',
    borderRadius: BorderRadius.xl,
    padding: Spacing.lg,
    gap: Spacing.md,
    ...Shadows.medium,
  },
  storeImage: {
    width: 70,
    height: 70,
    borderRadius: BorderRadius.lg,
    backgroundColor: Colors.backgroundGray,
  },
  storeInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  storeName: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },
  phoneButton: {
    alignSelf: 'flex-start',
    borderRadius: BorderRadius.md,
    overflow: 'hidden',
  },
  phoneButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
  },
  phoneText: {
    fontSize: FontSizes.sm,
    color: Colors.primary,
    fontWeight: FontWeights.semibold,
  },
  addressCard: {
    flexDirection: 'row',
    borderRadius: BorderRadius.xl,
    padding: Spacing.lg,
    gap: Spacing.md,
    ...Shadows.medium,
  },
  addressIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    overflow: 'hidden',
  },
  addressIconGradient: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addressText: {
    flex: 1,
    fontSize: FontSizes.md,
    color: Colors.textPrimary,
    lineHeight: 22,
  },
  itemCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
    gap: Spacing.md,
    ...Shadows.small,
  },
  itemImage: {
    width: 60,
    height: 60,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.backgroundGray,
  },
  itemInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginBottom: Spacing.xs,
  },
  itemQuantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  quantityBadge: {
    backgroundColor: Colors.primary + '15',
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: BorderRadius.sm,
  },
  itemQuantity: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.bold,
    color: Colors.primary,
  },
  itemUnitPrice: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  itemPrice: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
  },
  summaryCard: {
    borderRadius: BorderRadius.xl,
    padding: Spacing.lg,
    ...Shadows.medium,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  summaryLabel: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
  },
  summaryValue: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.medium,
    color: Colors.textPrimary,
  },
  summaryDivider: {
    height: 1,
    backgroundColor: Colors.border,
    marginVertical: Spacing.sm,
  },
  summaryLabelTotal: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
  },
  totalBadge: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.md,
  },
  summaryValueTotal: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
  },
  paymentMethodContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginTop: Spacing.md,
    paddingTop: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  paymentIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.primary + '15',
    alignItems: 'center',
    justifyContent: 'center',
  },
  paymentText: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
    fontWeight: FontWeights.medium,
  },
  actionsSection: {
    marginBottom: Spacing.lg,
  },
  actionButtonPrimary: {
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    marginBottom: Spacing.md,
    ...Shadows.medium,
  },
  actionButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Spacing.lg,
    gap: Spacing.sm,
  },
  actionButtonTextPrimary: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
  },
  secondaryActionsRow: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  actionButtonSecondary: {
    flex: 1,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    ...Shadows.small,
  },
  actionButtonSecondaryGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Spacing.md,
    gap: Spacing.xs,
  },
  actionButtonTextSecondary: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
  },
  helpButton: {
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    marginBottom: Spacing.xl,
  },
  helpButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Spacing.lg,
    gap: Spacing.sm,
  },
  helpText: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.primary,
  },
});
